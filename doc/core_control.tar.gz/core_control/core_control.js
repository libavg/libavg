
use("../libavg/src/avg.js");

function floatAnimationStep(nodeName, attrName, startValue, endValue, duration, curTime)
{
    var node = AVGPlayer.getElementByID(nodeName);
    if (curTime < duration) {
        var curValue = startValue+(endValue-startValue)*curTime/duration;
        eval("node."+attrName+"="+curValue);
        var code = "floatAnimationStep(\""+nodeName+"\", \""+attrName+"\", "
                +startValue+", "+endValue+", "+duration+", "+(curTime+30)+");";
        AVGPlayer.setTimeout(30, code);
    } else {
        eval("node."+attrName+"="+endValue);
    }
}

function animateFloatAttr(nodeName, attrName, startValue, endValue, duration)
{
    var code = "floatAnimationStep(\""+nodeName+"\", \""+attrName+"\", "
                +startValue+", "+endValue+", "+duration+", "+30+");";
    AVGPlayer.setTimeout(30, code);
}

var bIsElectro;

function switchMode() {
    var ActiveNode;
    var InactiveNode;
    if (bIsElectro) {
        InactiveNode = AVGPlayer.getElementByID("electrostatic_group");
        ActiveNode = AVGPlayer.getElementByID("magnetic_group");
        bIsElectro = false;
    } else {
        InactiveNode = AVGPlayer.getElementByID("magnetic_group");
        ActiveNode = AVGPlayer.getElementByID("electrostatic_group");
        bIsElectro = true;
    }
    InactiveNode.opacity = 0;
    ActiveNode.opacity = 1;
    
}

var rotLevel;
var energyLevel;
var magLevel;

function showLevels(name, level) {
    var i; 
    for (i=0; i<7; i++) {
        var curNode = AVGPlayer.getElementByID(name+"_level"+(i+1));
        if (i<level) {   
            curNode.opacity = 1;
        } else {
            curNode.opacity = 0.5;
        }
    }
}

function setLevels() {
    rotLevel=Math.random()*4+2;
    showLevels("rot", rotLevel);
    energyLevel=Math.random()*2+4;
    showLevels("energy", energyLevel);
    magLevel=Math.random()*5+1;
    showLevels("mag", magLevel);
}

function start()
{
    bIsElectro = false;
    AVGPlayer.setInterval(5000,"switchMode();");
}

function quit()
{
    AVGPlayer.stop();
}

var ok = AVGPlayer.loadFile("core_control.avg");
if (!ok) {
    print ("js: AVGPlayer.loadFile returned false");
}
AVGPlayer.setTimeout(100, "start();");
AVGPlayer.setInterval(100, "setLevels();");
AVGPlayer.play(25);
print("end");
